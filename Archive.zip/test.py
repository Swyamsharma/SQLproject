import sys

print("Python Version:", sys.version)
print("Platform:", sys.platform)
print("Executable Path:", sys.executable)
